# WangYiYun.bundle
a PLEX music plugin get info form wangyiyun

#部分设备上不能显示歌词的解决方法 http://www.plexmedia.cn/a/Plexplugin/20210504/159.html
